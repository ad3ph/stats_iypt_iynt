import functools
from colorama import Fore, Style

def welcome(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print(Fore.RED + f'Welcome to {func.__name__}!', end='')
        print(Style.RESET_ALL)
        return func(*args, **kwargs)
    return wrapper

def debug(func):
    '''Print the debug info incl. function name and arguments'''
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        funcs_args = [repr(a) for a in args]
        funcs_kwargs = [f"{kw}={val!r}" for kw, val in kwargs.items()]
        print(Fore.RED+'[DEBUG] ', end='')
        print(Style.RESET_ALL, end='')
        print(f"Called {func.__name__}({','.join(funcs_args + funcs_kwargs)})")
        value = func(*args, **kwargs)
        print(Fore.RED+'[DEBUG] ', end='')
        print(Style.RESET_ALL, end='')
        print(f"{func.__name__!r} returned {value!r}")
        return value
    return wrapper

def debug_this(func):
    '''Print the debug info incl. function name and arguments'''
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print(f"[DEBUG] {args[0]}, {kwargs['num']} раза ку")
        value = func(*args, **kwargs)
        print(f"[DEBUG] {func.__name__!r} returned {value!r}")
        return value
    return wrapper

def do_twice(func): #will be called as func1 = do_twice(func); func1(a,b)
    '''Calling the function twice'''
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)
        return func(*args, **kwargs)
    return wrapper

def repeat(func):
    '''Calling the function n times'''
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        for _ in range(kwargs['num']):
            val = func(*args, **kwargs)
        return val
    return wrapper

class CallsCounter:
    '''class hosting decorators that count function calls'''
    def __init__(self, func):
        functools.update_wrapper(self, func)
        self.func = func
        self.count = 0

    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f'Current count for function {self.func.__name__!r} calls is {self.count}')
        return self.func(*args, **kwargs)